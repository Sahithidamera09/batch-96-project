# Stock-Project
A web based application on stock trading.
